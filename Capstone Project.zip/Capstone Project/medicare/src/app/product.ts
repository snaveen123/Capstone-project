export class Product {
    id:number;
    name:string;
    price:number;
    Avatar:string;
    quantity:number
}
